package com.babbangona.barcodescannerproject;

import android.view.View;

/**
 * Created by DOREO on 27/09/2017.
 */

public interface ItemClickListener {
    void onClick(View view, int position);
}
