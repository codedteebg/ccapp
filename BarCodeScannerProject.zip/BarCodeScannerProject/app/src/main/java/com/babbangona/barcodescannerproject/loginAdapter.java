package com.babbangona.barcodescannerproject;

/**
 * Created by DOREO on 01/10/2017.
 */

public class loginAdapter {
}
